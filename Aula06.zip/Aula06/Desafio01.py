# DESAFIO 01 #
# Crie um programa que leiaa dois #
# E mostre a soma entre eles #

n1 = int(input('Digite um numero '))
n2 = int(input('Digite outro numero '))
s = n1 + n2
print('A soma de {} + {} = {}'.format(n1,n2,s))